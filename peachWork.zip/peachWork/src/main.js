import { createApp } from 'vue'
import App from './App.vue'
import ElementUI from 'element-ui';                      // 引入element-ui
import 'element-ui/lib/theme-chalk/index.css';           // element-ui的css样式要单独引入
createApp(App).mount('#app')
App.use(ElementUI)                                         //全局使用element-ui组件