<template>
  <div class="login-main">
    <el-container>
      <el-main>
        <div class="container">
          <div class="login-form">
            <h3>登陆界面</h3>
            <!-- 使用form元素包裹登录表单 -->
            <form @submit.prevent="login">
              <div class="changeDisplay border">
                <div class="app">
                  <el-button type="primary" @click="redirectToQQLogin">
                    <img src="../../assets/images/QQ.png" alt="无法显示" width="20px" height="20px"> QQ登录
                  </el-button>
                </div>
                <div class="app">
                  <el-button type="success" @click="redirectToWeChatLogin">
                    <img src="../../assets/images/Weixin.png" alt="无法显示" width="20px" height="20px"> 微信登录
                  </el-button>
                </div>
                <div class="app">
                  <el-button type="info">
                    <img src="../../assets/images/Pay.png" alt="无法显示" width="20px" height="20px"> 支付宝登录
                  </el-button>
                </div>
              </div>

              <div class="changeDisplay loginPart">
                <el-input placeholder="用户名" v-model="username"></el-input>
                <el-input type="password" placeholder="密码" v-model="password"></el-input>
                <div class="login">
                  <!-- 将按钮类型改为submit -->
                  <el-button type="success" native-type="submit">登录</el-button>
                </div>
              </div>

              <div class="clear"></div>

              <div class="register">
                <div><router-link to="/regist-main" class="regist">注册</router-link></div>
                <div><router-link to="/forget-password" class="regist">忘记密码？</router-link></div>
              </div>
            </form>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      password: ''
    };
  },
  mounted() {
    document.body.classList.add('loginBac');
  },
  destroyed() {
    document.body.classList.remove('loginBac');
  },
  methods: {
    login() {
      // 发送登录请求到后端
      this.$axios.post('http://localhost:8080/login', {
        name: this.username,
        password: this.password
      })
        .then(response => {
          // 处理登录成功的情况
          console.log(response.data);
          if (response.data.code === 401) { // 根据后端返回的状态码判断请求是否成功
            this.$message.error(response.data.msg); // 显示失败消息
          } else {
            this.$router.push("/home-main");
            this.$message.success(response.data.msg); // 显示成功消息
          }
        })
        .catch(error => {
          // 处理登录失败的情况
          this.$message.error('登录失败，请重试');
          console.error('登录错误:', error);
        });
    },
    redirectToQQLogin() {
      window.location.href = 'https://im.qq.com';
    },
    redirectToWeChatLogin() {
      window.location.href = 'https://www.wechat.com';
    },
    redirectToAlipayLogin() {
      window.location.href = 'https://auth.alipay.com';
    }
  }
};
</script>

<style scoped>
@import url("../../assets/css/css_mine.css");
</style>
