<template>
    <div class="container" style="padding:0px;">
        <div class="content">
            <div class="box">
                <div class="front">{{ userData.name }}</div>
                <div class="back">欢迎你</div>
            </div>
            <div class="content userData">
                <ul>
                    <li>余额: {{ userData.money }}</li>
                    <li>邮箱: {{ userData.email }}</li>
                    <li>生日: {{ userData.time }}</li>
                </ul>
            </div>
            <div style="padding:10px;background-color:white;">
                <div class="userPicture">
                    <el-image class="avatar_content" :src="avatar" fit="cover"></el-image>
                </div>
            </div>
        </div>
        <div class="content calendar">
            <el-calendar v-model="value" :style="{ width: '700px', height: '500px' }"></el-calendar>
        </div>
    </div>
</template>

<script>
    import axios from 'axios';

    export default {
        data() {
            return {
                value: new Date(),
                userData: null, // 存储用户数据的对象
                imageUrl: '',
                avatar: ''
            }
        },
        mounted() {
            // 在组件挂载后获取用户数据
            this.fetchUserData();
        },
        methods: {
            fetchUserData() {
                // 发送HTTP请求到后端获取用户数据
                // 假设您的后端接口地址是 http://localhost:8080/user/{userId}，并且userId存储在localStorage中
                const userId = localStorage.getItem('userId'); // 假设userId是用户的id
                axios.get(`http://localhost:8080/user/${userId}`)
                    .then(response => {
                        // 获取到用户数据后解构并更新userData对象
                        const { name, money, email, time, url } = response.data.data;
                        this.userData = { name, money, email, time };
                        this.imageUrl = url;
                        this.fetchUserPicture();
                    })
                    .catch(error => {
                        console.error('Error fetching user data:', error);
                    });
            },
            fetchUserPicture() {
                axios.get(`http://localhost:8080/getAvatar/${this.imageUrl}`)
                    .then(response => {
                        if (response.data.code === 0) {
                            this.avatar = response.data.img;
                        } else {
                            this.$message.error(response.data.msg);
                        }
                    })
                    .catch(error => {
                        console.log(error)
                    });
            }
        }
    }
</script>


<style scoped>
    ul {
        list-style-type: none;
        padding: 0;
    }

    li {
        background-color: #fff;
        border-radius: 3px;
        margin-bottom: 10px;
        font-size: 16px;
        color: #333;
    }

    li:before {
        content: "\2022";
        /* 使用实心圆点作为项目符号 */
        color: #FF5733;
        /* 修改圆点颜色 */
        display: inline-block;
        width: 1em;
        margin-left: -1em;
        /* 将圆点与文本对齐 */
    }

    .el-image__error,
    .el-image__inner,
    .el-image__placeholder {
        width: 100px;
    }

    img {
        width: 100px;
        height: auto;
        margin: 10px;
    }

    .container {
        height: 800px;
        display: flex;
    }

    .content {
        margin-right: 20px;
    }

    .calendar {
        background-color: #fff;
        height: 650px;
    }

    .box {
        position: relative;
        width: 100px;
        height: 100px;
        margin: 0px 50px 10px 60px;
        transition: all .6s;
        transform-style: preserve-3d;
    }

    .userPicture {
        margin: 10px;
        width: 200px;
        height: 200px;
        overflow: hidden;
        position: relative;
        background-color: #fff;
    }

    .box:hover {
        transform: rotateY(180deg);
    }

    .front,
    .back {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        font-size: 20px;
        color: #fff;
        text-align: center;
        line-height: 100px;
    }

    .front {
        background-color: rgb(251, 144, 22);
        z-index: 1;
        backface-visibility: hidden;
    }

    .back {
        background-color: rgb(5, 186, 144);
        transform: rotateY(180deg);
    }
</style>