<template>
  <div class="container" style="padding:0px;">
    <div class="content">
      <div class="box">
        <div class="front">欢迎你</div>
        <div class="back">Web实验1</div>
      </div>
      <div class="userPicture">
        <img src="../../../assets/images/user.png" alt="图片无法显示" title="用户头像">
      </div>
    </div>
    <div class="content calendar">
      <el-calendar v-model="value" :style="{ width: '700px', height: '500px' }"></el-calendar>
    </div>
  </div>
</template>


<style scoped>
    img{
        width: 200px;
        height: auto;
        margin:10px;
    }
    
    .container {
      height: 800px;
        display: flex;
    }

    .content {
        margin-right: 20px; 
    }

    .calendar{
      background-color: #fff;
      height:650px;
    }

    .box {
        position: relative;
        width: 100px;
        height: 100px;
        margin:0px 0px 10px 60px;
        transition: all .6s;
        transform-style: preserve-3d;
    }

    .userPicture{
        position: relative;
        background-color: #fff;
    }

    .box:hover {
        transform: rotateY(180deg);
    }

    .front,
    .back {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        border-radius: 50%;
        font-size: 20px;
        color: #fff;
        text-align: center;
        line-height: 100px;
    }

    .front {
        background-color: rgb(251, 144, 22);
        z-index: 1;
        backface-visibility: hidden;
    }

    .back {
        background-color: rgb(5, 186, 144);
        transform: rotateY(180deg);
    }
</style>

<script>
  export default {
    data() {
      return {
        value: new Date()
      }
    }
  }
</script>