<template>
    <div class="money-manage">
        <h1>我的余额：{{ balance }}</h1>
        <el-form :model="form" ref="form" label-width="80px" class="demo-ruleForm">
            <el-form-item label="金额" prop="amount">
                <el-input v-model.number="form.amount" placeholder="请输入金额"></el-input>
            </el-form-item>
            <el-form-item label="操作">
                <el-button type="primary" @click="deposit">充值</el-button>
                <el-button type="danger" @click="consume">消费</el-button>
            </el-form-item>
        </el-form>
    </div>
</template>

<script>
    import axios from 'axios';
    export default {
        data() {
            return {
                balance: 0, // 初始余额，页面加载时从后端获取
                form: {
                    amount: null // 充值或消费的金额
                }
            };
        },
        mounted() {
            // 页面加载时从后端获取初始余额
            this.fetchBalance();
        },
        methods: {
            fetchBalance() {
                // 发送HTTP请求到后端获取用户数据
                // 假设您的后端接口地址是 http://localhost:8080/user/{userId}，并且userId存储在localStorage中
                const userId = localStorage.getItem('userId'); // 假设userId是用户的id
                axios.get(`http://localhost:8080/user/${userId}`)
                    .then(response => {
                        // 获取到用户数据后解构并更新userData对象
                        const { money } = response.data.data;
                        this.balance = money;
                    })
                    .catch(error => {
                        console.error('Error fetching user data:', error);
                    });
            },
            deposit() {
                // 发送充值请求给后端
                this.updateBalance('deposit');
            },
            consume() {
                // 发送消费请求给后端
                this.updateBalance('consume');
            },
            updateBalance(action) {
                const amount = parseFloat(this.form.amount);
                if (!isNaN(amount) && amount > 0) {

                    // 发送请求给后端，假设后端接口地址为 '/api/updateBalance'
                    const userId = localStorage.getItem('userId'); // 假设userId是用户的id
                    axios.put(`http://localhost:8080/updateBalance/${userId}`, {
                        amount: amount,
                        action: action
                    })
                        .then(response => {
                            // 根据后端返回的数据更新前端余额数据
                            const msg = response.data;
                            this.resetForm();
                            if (action === 'deposit') {
                                this.$message.success('充值成功');
                            } else if (msg === '余额不足') {
                                this.$message.error('余额不足！');
                            }
                            else {
                                this.$message.success('消费成功');
                            }
                            this.fetchBalance();
                        })
                        .catch(error => {
                            console.error('Error updating balance:', error);
                            this.$message.error('操作失败，请重试');
                        });
                } else {
                    this.$message.error('请输入有效的金额');
                }
            },
            resetForm() {
                this.$refs.form.resetFields(); // 重置表单
            }
        }
    };
</script>

<style scoped>
    .money-manage {
        margin: 20px;
        height: 200px;
        border-radius: 10px;
        background-color: aliceblue;
    }

    h1{
        text-align: center;
        padding-top: 10px;
    }
    .demo-ruleForm {
        max-width: 400px;
        margin: 0 auto;
    }
</style>