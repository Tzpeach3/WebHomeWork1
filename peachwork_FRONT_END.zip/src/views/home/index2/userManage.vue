<template>
  <div>
    <el-header class="header">
      <el-button type="primary" plain @click="showDialog">+ 新增</el-button>
      <el-input class="input" placeholder="请输入内容" v-model="input" clearable></el-input>
      <el-button type="primary" icon="el-icon-search" @click="search">搜索</el-button>
    </el-header>
    
    <el-dialog
      title="新增/编辑数据"
      :visible.sync="dialogVisible"
      width="30%"
    >
      <el-form :model="formData" ref="formData" label-width="80px">
        <el-form-item label="日期" prop="date">
          <el-date-picker v-model="formData.date" type="date" placeholder="选择日期" :picker-options="pickerOptions"></el-date-picker>
        </el-form-item>
        <el-form-item label="姓名" prop="name">
          <el-input v-model="formData.name" placeholder="请输入姓名"></el-input>
        </el-form-item>
        <el-form-item label="性别" prop="sex">
          <el-radio-group v-model="formData.sex">
            <el-radio label="男">男</el-radio>
            <el-radio label="女">女</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item label="省份" prop="province">
          <el-input v-model="formData.province" placeholder="请输入省份"></el-input>
        </el-form-item>
        <el-form-item label="市区" prop="city">
          <el-input v-model="formData.city" placeholder="请输入市区"></el-input>
        </el-form-item>
        <el-form-item label="地址" prop="address">
          <el-input v-model="formData.address" placeholder="请输入地址"></el-input>
        </el-form-item>
        <el-form-item label="邮编" prop="zip">
          <el-input v-model="formData.zip" placeholder="请输入邮编"></el-input>
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="handleCancel">取 消</el-button>
        <el-button type="primary" @click="saveData">{{ editingIndex === null ? '新增' : '保存' }}</el-button>
      </span>
    </el-dialog>
    
    <el-table
      :data="tableData"
      border
      style="width: 100%"
    >
      <el-table-column prop="date" label="日期"></el-table-column>
      <el-table-column prop="name" label="姓名"></el-table-column>
      <el-table-column prop="sex" label="性别"></el-table-column>
      <el-table-column prop="province" label="省份"></el-table-column>
      <el-table-column prop="city" label="市区"></el-table-column>
      <el-table-column prop="address" label="地址"></el-table-column>
      <el-table-column prop="zip" label="邮编"></el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="primary" size="mini" @click="editData(scope.row)" style="margin-left: 10px;">编辑</el-button>
          <el-button type="danger" size="mini" @click="confirmDelete(scope.row)" style="margin-left: 10px">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  data() {
    return {
      dialogVisible: false,
      formData: {
        date: '',
        name: '',
        sex: '',
        province: '',
        city: '',
        address: '',
        zip: ''
      },
      pickerOptions: {
        disabledDate(time) {
          // Disable dates after today
          return time.getTime() > Date.now();
        }
      },
      input: '',
      tableData: [],
      editingIndex: null // 记录正在编辑的行索引
    };
  },
  methods: {
    // 获取用户信息列表
    getUserInformation() {
      axios.get('http://localhost:8080/get-user-information')
        .then(response => {
          this.tableData = response.data;
        })
        .catch(error => {
          console.error('获取用户信息失败:', error);
        });
    },
    // 显示新增/编辑数据对话框
    showDialog() {
      this.dialogVisible = true;
      // 重置表单数据和编辑索引
      this.formData = {
        date: '',
        name: '',
        sex: '',
        province: '',
        city: '',
        address: '',
        zip: ''
      };
      this.editingIndex = null;
    },
    // 保存或编辑数据
    saveData() {
      // 提取日期部分
      // const formattedDate = new Date(this.formData.date).toISOString().split('T')[0];
      // this.formData.date = formattedDate;
  // 从表单中获取日期字符串
  const dateString = this.formData.date;

  // 创建一个新的 Date 对象，使用输入的日期字符串
  const dateObject = new Date(dateString);

  // 提取日期部分（年、月、日），不包括时分秒
  const year = dateObject.getFullYear();
  const month = dateObject.getMonth() + 1; // 月份从0开始，需要加1
  const day = dateObject.getDate();

  // 格式化成 YYYY-MM-DD 的形式
  const formattedDate = `${year}-${month < 10 ? '0' + month : month}-${day < 10 ? '0' + day : day}`;

  // 更新表单中的日期值
  this.formData.date = formattedDate;
      if (this.editingIndex === null) {
        // 新增数据
        axios.post('http://localhost:8080/save-user-information', this.formData)
          .then(response => {
            console.log('数据新增成功:', response.data);
            this.getUserInformation();
            this.dialogVisible = false;
          })
          .catch(error => {
            console.error('新增数据失败:', error);
          });
      } else {
        // 编辑现有数据
        axios.put(`http://localhost:8080/update-user-information/${this.tableData[this.editingIndex].id}`, this.formData)
          .then(response => {
            console.log('数据编辑成功:', response.data);
            this.getUserInformation();
            this.dialogVisible = false;
          })
          .catch(error => {
            console.error('编辑数据失败:', error);
          });
      }
    },
    // 编辑数据
    editData(row) {
      // 填充表单数据
      this.formData = { ...row };
      // 设置编辑索引
      this.editingIndex = this.tableData.indexOf(row);
      // 显示对话框
      this.dialogVisible = true;
    },
    // 确认删除
    confirmDelete(row) {
      this.$confirm('此操作将永久删除该数据，是否继续？', '警告', {
        confirmButtonText: '确定',
        cancelButtonText: '取消',
        type: 'warning'
      }).then(() => {
        // 如果确认，执行删除操作
        this.deleteData(row);
      }).catch(() => {
        // 如果取消，不执行任何操作
      });
    },
    // 删除数据
    deleteData(row) {
      axios.delete(`http://localhost:8080/delete-user-information/${row.id}`)
        .then(response => {
          console.log('数据删除成功:', response.data);
          this.getUserInformation();
        })
        .catch(error => {
          console.error('删除数据失败:', error);
        });
    },
    // 搜索用户信息
    search() {
      axios.get('http://localhost:8080/search-user-information', {
        params: {
          keyword: this.input
        }
      })
      .then(response => {
        this.tableData = response.data;
      })
      .catch(error => {
        console.error('搜索失败:', error);
      });
    },
    // 取消新增/编辑操作
    handleCancel() {
      this.dialogVisible = false;
      // 重置表单数据和编辑索引
      this.formData = {
        date: '',
        name: '',
        sex: '',
        province: '',
        city: '',
        address: '',
        zip: ''
      };
      this.editingIndex = null;
    }
  },
  mounted() {
    this.getUserInformation();
  }
};
</script>

<style>
.header {
  display: flex;
  align-items: center;
}

.input {
  width: 200px;
  margin-left: auto; 
}
</style>
