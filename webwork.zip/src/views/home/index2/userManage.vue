<template>
  <div>
<el-header class="header">
    <el-button type="primary" plain>+ 新增</el-button>
    <el-input class="input" placeholder="请输入内容" v-model="input" clearable></el-input>
    <el-button type="primary" icon="el-icon-search" >搜索</el-button>
  </el-header>
  <el-table
    :data="tableData"
    border
    style="width: 100%">
    <el-table-column
      fixed
      prop="date"
      label="日期"
      width="150">
    </el-table-column>
    <el-table-column
      prop="name"
      label="姓名"
      width="120">
    </el-table-column>
        <el-table-column
      prop="sex"
      label="性别"
      width="120">
    </el-table-column>
    <el-table-column
      prop="province"
      label="省份"
      width="120">
    </el-table-column>
    <el-table-column
      prop="city"
      label="市区"
      width="120">
    </el-table-column>
    <el-table-column
      prop="address"
      label="地址"
      width="300">
    </el-table-column>
    <el-table-column
      prop="zip"
      label="邮编"
      width="120">
    </el-table-column>
    <el-table-column
      fixed="right"
      label="操作"
      width="100">
      <template slot-scope="scope">
        <el-button @click="handleClick(scope.row)" type="text" size="small">查看</el-button>
        <el-button type="text" size="small">编辑</el-button>
      </template>
    </el-table-column>
  </el-table>
  </div>
</template>

<script>
  export default {
    
    methods: {
      handleClick(row) {
        console.log(row);
      }
    },

    data() {
      return {
        input:'',
        tableData: [{
          date: '2024-04-23',
          name: '陶梓',
          sex:'男',
          province: '武汉',
          city: '洪山区',
          address: '武汉理工大学南湖校区',
          zip: 1
        }, {
          date: '2024-04-24',
          name: '王二',
          sex:'女',
          province: '武汉',
          city: '洪山区',
          address: '武汉理工大学南湖校区',
          zip: 2
        }, {
          date: '2023-04-25',
          name: '张三',
          sex:'男',
          province: '武汉',
          city: '洪山区',
          address: '武汉理工大学南湖校区',
          zip: 3
        }, {
          date: '2016-04-26',
          name: '李四',
          sex:'男',
          province: '武汉',
          city: '洪山区',
          address: '武汉理工大学南湖校区',
          zip: 4
        }]
      }
    }
  }
</script>

<style>
.header {
  display: flex;
  align-items: center;
}

.input {
  width: 200px;
  margin-left: auto; 
}
</style>