<template>
    <el-main>
        <el-table :data="tableData">
          <el-table-column prop="date" label="日期" width="140">
          </el-table-column>
          <el-table-column prop="name" label="姓名" width="120">
          </el-table-column>
          <el-table-column prop="address" label="地址">
          </el-table-column>
        </el-table>
      </el-main>
</template>

<script>
export default{
data() {
    const item = {
      date: "2024-04-23",
      name: "陶梓",
      address: "武汉市洪山区武汉理工大学南湖校区"
    };
    return {
      tableData: Array(6).fill(item)
    };
  }
};
</script>