<template>
<el-container>
  <el-aside width="200px" class="hiddenChange"> <NavMenu /></el-aside>
  <el-container>
    <el-header style="text-align: right; font-size: 12px;width: 100%;">
      <span>
      <el-avatar style="font-size:small"> 陶梓 </el-avatar>
      </span>
    </el-header>
    <el-main><router-view/></el-main>
  </el-container>
</el-container>
</template>

<script>
import NavMenu from './navMenu.vue'
export default {
  methods:{
  },
  components:{
    NavMenu
  }
};
</script>

<style scoped>
  body{
    background-image: none;
    background-color: white;
  }
  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
  }
  .el-avatar{
    margin-top:10px;
  }
  .el-dropdown{
    font-size:25px;
  }
  .el-header {
    background-color: #B3C0D1;
    color: #333;
    line-height: 60px;
    width:auto;
  }
  
  .el-aside {
    color: #333;
  }
@media screen and (max-width: 1000px) {
  .hiddenChange{
    display: none;
  }
}
</style>
