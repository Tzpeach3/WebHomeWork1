<template>
<el-container style="height: 100vh;">
  <el-aside width="200px" class="hiddenChange"> <NavMenu /></el-aside>
  <el-container>
    <el-header style="text-align: right; font-size: 12px;width: 100%;">
      <span>
        <el-avatar style="font-size:small"> 陶梓 </el-avatar>
      </span>
    </el-header>
    <el-main><router-view/></el-main>
  </el-container>
</el-container>
</template>

<script>
import NavMenu from './navMenu.vue'
export default {
  methods:{},
  components:{ NavMenu }
};
</script>

<style scoped>
  /* 重置一些用户代理样式 */
  body, html {
    margin: 0;
    padding: 0;
    width: 100%;
    height: 100%;
    overflow: hidden; /* 确保没有额外的滚动条 */
    background-image: none; /* 去除背景图片 */
  }

  .el-container {
    background-color: var(--main-theme);
  }

  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
    min-height: 400px;
  }

  .el-avatar {
    margin-top: 10px;
  }

  .el-dropdown {
    font-size: 25px;
  }

  .el-header {
    background-color: var(--main-header-theme);
    line-height: 60px;
    width: auto;
  }

  @media screen and (max-width: 1000px) {
    .hiddenChange {
      display: none;
    }
  }
</style>
