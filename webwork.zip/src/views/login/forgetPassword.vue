<template>
  <div class="forgetPassword">
    <el-container>
      <el-main>
        <div class="container">
          <div class="login-form">
            <h3>修改密码</h3>
            <!-- 添加form元素包裹密码输入框 -->
            <form @submit.prevent="changePassword">
              <div class="changeDisplay border2">
                <el-input placeholder="用户名" v-model="username"></el-input>
                <el-input type="password" placeholder="旧密码" v-model="oldPassword"></el-input>
              </div>
              <div class="changeDisplay border3">
                <el-input type="password" placeholder="新密码" v-model="password"></el-input>
                <el-input type="password" placeholder="确认密码" v-model="confirmPassword"></el-input>
              </div>
              <div class="clear"></div>
              <div class="register">
                <!-- 将按钮类型改为submit -->
                <div><button type="submit" class="useButton">修改密码</button></div>
                <div><router-link to="/" class="regist">返回登陆界面</router-link></div>
              </div>
            </form>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      oldPassword:'',
      password: '',
      confirmPassword: ''
    };
  },
  mounted() {
    document.body.classList.add('loginBac');
  },
  destroyed() {
    document.body.classList.remove('loginBac');
  },
  methods: {
    changePassword() {
      // 验证用户名和密码不能为空
      if (!this.username|| !this.oldPassword || !this.password || !this.confirmPassword) {
        this.$message.error('用户名和密码不能为空');
        return;
      }
      // 检查密码长度是否在5到8位之间
      if (this.password.length < 5 || this.password.length > 8) {
        this.$message.error('密码长度必须在5到8位之间');
        return;
      }
      // 在这里添加修改密码的逻辑
      if (this.password === this.confirmPassword) {
        // 发送修改密码请求等等
        this.$message.success('密码修改成功');
        this.$router.push("/login-main");
      } else {
        this.$message.error('两次密码不一致');
      }
    }
  }
};
</script>

<style scoped>
@import url("../css/css_mine.css");
</style>
