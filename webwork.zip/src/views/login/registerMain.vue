<template>
  <div class="regist-main">
    <el-container>
      <el-main>
        <div class="container">
          <div class="login-form">
            <h3>注册</h3>
            <!-- 使用form元素包裹注册表单 -->
            <form @submit.prevent="register">
              <div class="changeDisplay border2">
                <el-input placeholder="用户名" v-model="username"></el-input>
                <el-input type="password" placeholder="密码" v-model="password"></el-input>
                <el-input type="email" placeholder="电子邮箱" v-model="email"></el-input>
                <el-date-picker
                  placeholder="日期"
                  v-model="birthdate"
                  :picker-options="pickerOptions">
                </el-date-picker>
              </div>
              <div class="changeDisplay border3">
                <div class="textUse"><h6 style="text-align: center;margin: 0px;">请上传图像</h6></div>
                <el-upload
                  class="avatar-uploader"
                  action="https://jsonplaceholder.typicode.com/posts/"
                  :show-file-list="false"
                  :on-success="handleAvatarSuccess"
                  :before-upload="beforeAvatarUpload">
                  <img v-if="imageUrl" :src="imageUrl" class="avatar">
                  <i v-else class="el-icon-plus avatar-uploader-icon"></i>
                </el-upload>
              </div>
              <div class="reRegist"></div>
              <div class="clear"></div>

              <div class="register">
                <!-- 将按钮类型改为submit -->
                <div><button type="submit" class="useButton">注册</button></div>
                <div><router-link to="/" class="regist">返回登录界面</router-link></div>
              </div>
            </form>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      imageUrl: '',
      username: '',
      password: '',
      email: '',
      birthdate: '',
      pickerOptions: {
        disabledDate(time) {
          // Disable dates after today
          return time.getTime() > Date.now();
        }
      }
    };
  },
  mounted() {
    document.body.classList.add('loginBac');
  },
  destroyed() {
    document.body.classList.remove('loginBac');
  },
  methods: {
    handleAvatarSuccess(res, file) {
      this.imageUrl = URL.createObjectURL(file.raw);
    },
    beforeAvatarUpload(file) {
      const isJPG = file.type === 'image/jpeg';
      const isLt2M = file.size / 1024 / 1024 < 2;

      if (!isJPG) {
        this.$message.error('上传头像图片只能是 JPG 格式!');
      }
      if (!isLt2M) {
        this.$message.error('上传头像图片大小不能超过 2MB!');
      }
      return isJPG && isLt2M;
    },
    register() {
      // 在这里添加注册逻辑
      if (!this.username || !this.password || !this.email || !this.birthdate) {
        this.$message.error('所有字段都是必填的');
        return;
      }
      // 检查密码长度是否在5到8位之间
      if (this.password.length < 5 || this.password.length > 8) {
        this.$message.error('密码长度必须在5到8位之间');
        return;
      }
      // 检查邮箱格式是否正确
      const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      if (!emailPattern.test(this.email)) {
        this.$message.error('邮箱格式不正确');
        return;
      }

      // 发送注册请求等等
      this.$router.push("/login-main");
      this.$message.success('注册成功');
    }
  }
};
</script>

<style scoped>
@import url("../css/css_mine.css");
.el-date-editor.el-input,
.el-date-editor.el-input__inner {
  width: 100%;
}
.avatar-uploader .el-upload {
  border: 1px dashed #fff;
  border-radius: 6px;
  cursor: pointer;
  position: relative;
  overflow: hidden;
}
.avatar-uploader .el-upload:hover {
  border-color: #409eff;
}
.avatar-uploader-icon {
  font-size: 28px;
  color: #8c939d;
  background-color: #fff;
  width: 178px;
  height: 133px;
  line-height: 138px;
  text-align: center;
  border: 1px solid #dcdfe6;
  border-radius: 4px;
}

@media screen and (max-width: 650px) {
  .avatar-uploader-icon{
    margin-left: -13%;
  }

  .textUse{
    margin-left: -8%;
  }
}

.avatar {
  width: 178px;
  height: 178px;
  display: block;
}
</style>
