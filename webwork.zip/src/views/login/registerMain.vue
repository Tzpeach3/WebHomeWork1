<template>
  <div class="regist-main">
    <el-container>
      <el-main>
        <div class="container">
          <div class="login-form">
            <h3>注册</h3>
            <div class="changeDisplay border2">
              <el-input placeholder="用户名" v-model="username"></el-input>
              <el-input type="password" placeholder="密码" v-model="password"></el-input>
            </div>
            <div class="changeDisplay border3">
              <el-input type="email" placeholder="电子邮箱" v-model="email"></el-input>
              <el-date-picker
                placeholder="日期"
                v-model="birthdate"
                :picker-options="pickerOptions">
              </el-date-picker>
            </div>
            <div class="reRegist">
              <el-button type="success" @click="register">注册</el-button>
            </div>
            <div class="clear"></div>

            <div class="register return">
              <!-- 修改这里的 <a> 标签为 <router-link> 组件 -->
              <div><router-link to="/" class="regist">返回登录界面</router-link></div>
            </div>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      password: '',
      email: '',
      birthdate: '',
      pickerOptions: {
        disabledDate(time) {
          // Disable dates after today
          return time.getTime() > Date.now();
        }
      }
    };
  },
  mounted() {
    document.body.classList.add('loginBac');
  },
  destroyed() {
    document.body.classList.remove('loginBac');
  },
  methods: {
    register() {
      // 在这里添加注册逻辑
      if (!this.username || !this.password || !this.email || !this.birthdate) {
        this.$message.error('所有字段都是必填的');
        return;
      }
      // 检查密码长度是否在5到8位之间
      if (this.password.length < 5 || this.password.length > 8) {
        this.$message.error('密码长度必须在5到8位之间');
        return;
      }
      // 检查邮箱格式是否正确
      const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;
      if (!emailPattern.test(this.email)) {
        this.$message.error('邮箱格式不正确');
        return;
      }
      
      // 发送注册请求等等
      this.$router.push("/login-main");
      this.$message.success('注册成功');
    }
  }
};
</script>

<style scoped>
@import url("../css/css_mine.css");
.el-date-editor.el-input, .el-date-editor.el-input__inner{
  width:100%;
}
</style>
