<template>
  <div class="login-main">
    <el-container>
      <el-main>
        <div class="container">
          <div class="login-form">
            <h3>登陆界面</h3>
            <!-- 使用form元素包裹登录表单 -->
            <form @submit.prevent="login">
              <div class="changeDisplay border">
                <div class="app">
                  <el-button type="primary" @click="redirectToQQLogin">
                    <img src="../images/QQ.png" alt="无法显示" width="20px" height="20px"> QQ登录
                  </el-button>
                </div>
                <div class="app">
                  <el-button type="success" @click="redirectToWeChatLogin">
                    <img src="../images/Weixin.png" alt="无法显示" width="20px" height="20px"> 微信登录
                  </el-button>
                </div>
                <div class="app">
                  <el-button type="info">
                    <img src="../images/Pay.png" alt="无法显示" width="20px" height="20px"> 支付宝登录
                  </el-button>
                </div>
              </div>

              <div class="changeDisplay loginPart">
                <el-input placeholder="用户名" v-model="username"></el-input>
                <el-input type="password" placeholder="密码" v-model="password"></el-input>
                <div class="login">
                  <!-- 将按钮类型改为submit -->
                  <el-button type="success" native-type="submit">登录</el-button>
                </div>
              </div>

              <div class="clear"></div>

              <div class="register">
                <div><router-link to="/regist-main" class="regist">注册</router-link></div>
                <div><router-link to="/forget-password" class="regist">忘记密码？</router-link></div>
              </div>
            </form>
          </div>
        </div>
      </el-main>
    </el-container>
  </div>
</template>

<script>
export default {
  data() {
    return {
      username: '',
      password: ''
    };
  },
  mounted() {
    document.body.classList.add('loginBac');
  },
  destroyed() {
    document.body.classList.remove('loginBac');
  },
  methods: {
    login() {
      // 在这里添加登录逻辑
      if (!this.username || !this.password) {
        this.$message.error('用户名和密码不能为空');
        return;
      }
      
      // 检查密码长度是否在5到8位之间
      if (this.password.length < 5 || this.password.length > 8) {
        this.$message.error('密码长度必须在5到8位之间');
        return;
      }
      
      // 发送登录请求
      this.$message.success('登录成功');
      this.$router.push("/home-main");
    },
    redirectToQQLogin() {
      window.location.href = 'https://im.qq.com';
    },
    redirectToWeChatLogin() {
      window.location.href = 'https://www.wechat.com';
    },
    redirectToAlipayLogin() {
      window.location.href = 'https://auth.alipay.com';
    }
  }
};
</script>

<style scoped>
@import url("../css/css_mine.css");
</style>
