<template>
  <div id="app">
    <router-view/>
  </div>
</template>

<style>
/* 定义全局的css变量 */
:root {
  /* 背景色 */
  --theme_bg_color: white;
}
</style>