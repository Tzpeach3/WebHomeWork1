package com.peachwork.peachwork.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.peachwork.peachwork.entity.Result;
import com.peachwork.peachwork.entity.ResultUtil;
import com.peachwork.peachwork.entity.User;
import com.peachwork.peachwork.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class ForgetPasswordController {

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/reset-password")
    public Result resetPassword(@RequestBody UserResetRequest request) {
        // 构建查询条件
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("name", request.getUsername()).eq("password", request.getOldPassword());
        // 查询用户信息
        User dbUser = userMapper.selectOne(wrapper);
        // 如果找到用户并且旧密码匹配
        if (dbUser != null&&dbUser.getPassword().equals(request.getOldPassword())) {
            // 更新密码
            dbUser.setPassword(request.getNewPassword());
            userMapper.updateById(dbUser);
            return ResultUtil.changeSuccess("密码修改成功");
        } else {
            return ResultUtil.error(500, "用户名或旧密码错误");
        }
    }

    static class UserResetRequest {
        private String username;
        private String oldPassword;
        private String newPassword;

        // Getter and setter methods
        public String getUsername() {
            return username;
        }

        public void setUsername(String username) {
            this.username = username;
        }

        public String getOldPassword() {
            return oldPassword;
        }

        public void setOldPassword(String oldPassword) {
            this.oldPassword = oldPassword;
        }

        public String getNewPassword() {
            return newPassword;
        }

        public void setNewPassword(String newPassword) {
            this.newPassword = newPassword;
        }
    }
}
