package com.peachwork.peachwork.controller;

import com.alibaba.fastjson2.JSONObject;
import org.apache.commons.io.IOUtils;
import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.util.ResourceUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

@RestController
public class GetAvatarController {
    private static final String avatar_url = "E:/picture/";

    @GetMapping("/getAvatar/{imgID}")
    public JSONObject GetUserAvatar(@PathVariable String imgID){
        JSONObject result = new JSONObject();
        try{
            File file = ResourceUtils.getFile(avatar_url + imgID);
            FileInputStream fileInputStream = new FileInputStream(file);
            //使用IO流将其转换为字节数组
            byte[] bytes = IOUtils.toByteArray(fileInputStream);
            //将字节转换为base64
            String encodeBase64 = "data:image/jpeg;base64," + Base64.encodeBase64String(bytes);
            //关闭IO流
            fileInputStream.close();
            result.put("code",0);
            result.put("img",encodeBase64);
        } catch (IOException f){
            f.printStackTrace();
            result.put("code",1);
            result.put("msg","头像获取失败！");
        }
        return result;
    }
}
