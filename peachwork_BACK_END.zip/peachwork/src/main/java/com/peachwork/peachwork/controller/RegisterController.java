package com.peachwork.peachwork.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.peachwork.peachwork.entity.Result;
import com.peachwork.peachwork.entity.ResultUtil;
import com.peachwork.peachwork.entity.User;
import com.peachwork.peachwork.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class RegisterController {

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/register")
    public Result register(@RequestBody User user) {
        // 检查用户名是否已存在
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("name", user.getName());
        User existingUser = userMapper.selectOne(wrapper);
        if (existingUser != null) {
            return ResultUtil.error(400, "用户名已存在");
        }

        // 在这里添加其他注册逻辑，比如密码加密等

        // 保存用户信息到数据库
        int rows = userMapper.insert(user);
        if (rows > 0) {
            return ResultUtil.registerSuccess("注册成功");
        } else {
            return ResultUtil.error(500, "注册失败，请重试");
        }
    }
}
