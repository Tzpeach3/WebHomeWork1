package com.peachwork.peachwork.controller;

import com.alibaba.fastjson2.JSONObject;
import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.peachwork.peachwork.entity.Result;
import com.peachwork.peachwork.entity.ResultUtil;
import com.peachwork.peachwork.entity.User;
import com.peachwork.peachwork.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Objects;

@RestController
public class RegisterController {

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/register")
    public Result register(@RequestBody User user) {
        // 检查用户名是否已存在
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        QueryWrapper<User> wrapper2 = new QueryWrapper<>();
        wrapper.eq("name", user.getName());
        User existingUser = userMapper.selectOne(wrapper);
        if (existingUser != null) {
            return ResultUtil.error(400, "用户名已存在");
        }
        wrapper2.eq("email", user.getEmail());
        User existingUser2 = userMapper.selectOne(wrapper2);
        if (existingUser2 != null) {
            return ResultUtil.error(401, "邮箱已经被注册");
        }
        // 在这里添加其他注册逻辑，比如密码加密等

        // 保存用户信息到数据库
        int rows = userMapper.insert(user);
        if (rows > 0) {
            return ResultUtil.registerSuccess("注册成功");
        } else {
            return ResultUtil.error(500, "注册失败，请重试");
        }
    }

    private static final String avatar_url = "E:/picture/";

    @PostMapping( "/avatar")
    public JSONObject Avatar(@RequestParam("file") MultipartFile file){
        JSONObject result = new JSONObject();

        if (!file.isEmpty()) {
            SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd...HH-mm-ss...SSS");
            String formattedDate = format.format(new Date());
            String[] fileCut = Objects.requireNonNull(file.getOriginalFilename()).split("\\.");
            String fileType = fileCut[fileCut.length-1];
            String fileName = formattedDate + "." + fileType;
            try {
                BufferedOutputStream out = new BufferedOutputStream(
                        new FileOutputStream(avatar_url + fileName));
                out.write(file.getBytes());
                out.flush();
                out.close();
            } catch (IOException e) {
                e.printStackTrace();
                result.put("code",1);
                result.put("msg","上传失败," + e.getMessage());
                return result;
            }
            result.put("code",0);
            result.put("imgID",fileName);
            result.put("msg","上传成功");
        } else {
            result.put("code",2);
            result.put("msg","上传失败,因为文件是空的");
        }
        return result;

    }
}
