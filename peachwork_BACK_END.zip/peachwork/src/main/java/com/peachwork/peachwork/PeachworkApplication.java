package com.peachwork.peachwork;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.peachwork.peachwork.mapper")
public class PeachworkApplication {

    public static void main(String[] args) {
        SpringApplication.run(PeachworkApplication.class, args);
    }

}
