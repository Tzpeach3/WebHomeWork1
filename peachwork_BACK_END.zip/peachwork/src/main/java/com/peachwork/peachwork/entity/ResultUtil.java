package com.peachwork.peachwork.entity;

public class ResultUtil {

    /**成功且带数据**/
    public static Result loginSuccess(Object object){
        Result result = new Result();
        result.setCode(ResultEnum.LOGIN.getCode());
        result.setMsg(ResultEnum.LOGIN.getMsg());
        result.setData(object);
        return result;
    }

    /**成功但不带数据**/
    public static Result loginSuccess(){

        return loginSuccess(null);
    }

    public static Result registerSuccess(Object object){
        Result result = new Result();
        result.setCode(ResultEnum.REGISTER.getCode());
        result.setMsg(ResultEnum.REGISTER.getMsg());
        result.setData(object);
        return result;
    }

    /**成功但不带数据**/
    public static Result registerSuccess(){

        return registerSuccess(null);
    }

    public static Result changeSuccess(Object object){
        Result result = new Result();
        result.setCode(ResultEnum.CHANGE_PASSWORD.getCode());
        result.setMsg(ResultEnum.CHANGE_PASSWORD.getMsg());
        result.setData(object);
        return result;
    }

    /**成功但不带数据**/
    public static Result changeSuccess(){

        return changeSuccess(null);
    }


    /**失败**/
    public static Result error(Integer code,String msg){
        Result result = new Result();
        result.setCode(code);
        result.setMsg(msg);
        return result;
    }
}