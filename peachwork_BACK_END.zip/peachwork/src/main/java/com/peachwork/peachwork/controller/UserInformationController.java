package com.peachwork.peachwork.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import com.peachwork.peachwork.entity.UserInformation;
import com.peachwork.peachwork.mapper.UserInformationMapper;

import java.util.List;

@RestController
public class UserInformationController {

    @Autowired
    private UserInformationMapper userInformationMapper;

    @GetMapping("/get-user-information")
    public List<UserInformation> getUserInformation() {
        return userInformationMapper.selectList(null);
    }

    @GetMapping("/get-total-count")
    public int getTotalCount() {
        return Math.toIntExact(userInformationMapper.selectCount(null));
    }

    @PostMapping("/save-user-information")
    public String saveUserInformation(@RequestBody UserInformation userInformation) {
        try {
            userInformationMapper.insert(userInformation);
            return "保存成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "保存失败";
        }
    }

    @GetMapping("/search-user-information")
    public List<UserInformation> searchUserInformation(@RequestParam String keyword) {
        QueryWrapper<UserInformation> queryWrapper = new QueryWrapper<>();
        // 使用 MyBatis-Plus 提供的 like 方法进行模糊搜索
        queryWrapper.like("name", keyword);
        return userInformationMapper.selectList(queryWrapper);
    }

    @PutMapping("/update-user-information/{id}")
    public String updateUserInformation(@PathVariable Integer id, @RequestBody UserInformation userInformation) {
        try {
            userInformation.setId(id);
            userInformationMapper.updateById(userInformation);
            return "更新成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "更新失败";
        }
    }

    @DeleteMapping("/delete-user-information/{id}")
    public String deleteUserInformation(@PathVariable Integer id) {
        try {
            userInformationMapper.deleteById(id);
            return "删除成功";
        } catch (Exception e) {
            e.printStackTrace();
            return "删除失败";
        }
    }
}
