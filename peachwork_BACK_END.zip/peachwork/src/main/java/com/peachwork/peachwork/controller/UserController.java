// UserController.java

package com.peachwork.peachwork.controller;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.peachwork.peachwork.entity.Result;
import com.peachwork.peachwork.entity.ResultUtil;
import com.peachwork.peachwork.entity.User;
import com.peachwork.peachwork.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

/**
 * @author Tz
 */
@RestController
@RequestMapping
public class UserController {

    @Autowired
    private UserMapper userMapper;

    @PostMapping("/login")
    public Result login(@RequestBody User user) {
        System.out.println(user.getName());
        // 从数据库中根据用户名查询用户信息
//        User dbUser = userMapper.selectById(1);
        // 使用条件构造器查询用户信息
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("name", user.getName());
        User dbUser = userMapper.selectOne(wrapper);
//        System.out.println(dbUser);
        // 检查用户是否存在，并验证密码是否匹配
        if (dbUser != null && dbUser.getPassword().equals(user.getPassword())) {
            return ResultUtil.loginSuccess(dbUser.getId());
        } else {
            String str="用户或密码错误，请重新登录";
            return ResultUtil.error(401,str);
        }
    }

    @GetMapping("/user/{id}")
    public Result getUserById(@PathVariable Integer id) {
        // 根据用户id从数据库中查询用户信息
        User user = userMapper.selectById(id);
        if (user != null) {
            return ResultUtil.loginSuccess(user);
        } else {
            String str = "用户不存在";
            return ResultUtil.error(404, str);
        }
    }

}
